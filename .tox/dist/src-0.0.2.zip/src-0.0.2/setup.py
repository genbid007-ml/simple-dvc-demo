from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.2",
    description="its a wine Q package", 
    author="genbid007",
    packages=find_packages(),
    license="MIT"
)

